#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
  ifstream inFile("fruit.txt");
  if (!inFile.is_open()){
    cout<< "Error:fruit.txt could not be opened!";
    return 1;
  }
  cout<< "---Contents of fruit.txt---"<< endl;
  string line;
  while (getline(inFile, line)){
    cout<< line<< endl;

    inFile.close();

    ofstream outFile("fruit.txt", ios::app);
    if (!outFile.is_open()){
        cout<< "Error: Could not open fruit.txt for appending!"<< endl;
        return 1;
    }
     outFile<< "Fresh Fruits"<< endl;
     outFile.close();

     cout<< "/n'Fresh Fruits' has been added to fruit.txt successfully!"<< endl;
     }

    return 0;
}
