#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct person{
   string name;
   int age;
   };

int main()
{
  int n;
  cout<< "How many persons do you want to add?";
  cin>> n;

  if (n<= 0){
    cout<< "Number of persons must be greater than 0."<< endl;
    return 1;
  }
  ofstream outFile("persons.txt");
  if (!outFile.is_open()){
    cout<< "Error: Could not open persons.txt for writing!"<< endl;
    return 1;
  }
  for (int i=0; i<n; i++){
    string name;
    int age;
    cout<< "Error person"<< (i+1)<< "name (one word, e.g.Ali):";
    cin>> name;
    cout<< "Enter person"<< (i+1)<< "age:";
    cin>> age;

    outFile<< name<< " " <<age<< endl;
  }
    outFile.close();

    ifstream inFile("persons.txt");
    if (!inFile.is_open()){
        cout<< "Error: Could not open persons.txt for reading!"<< endl;
        return 1;
    }
    vector<person> persons;
    person temp;
    while (inFile>> temp.name>> temp.age){
        persons.push_back(temp);
    }
    inFile.close();

    if (persons.empty()){
        cout<< "No persons found in file."<< endl;
        return 1;
    }
    person youngest = persons[0];
    person oldest= persons[0];

    for (size_t i=1; i<persons.size(); i++){
        if (persons[i].age< youngest.age){
            youngest= persons[i];
        }
        if(persons[i].age> oldest.age){
            oldest= persons[i];
        }
    }
    ofstream resFile("result.txt");
    if (!resFile.is_open()){
        cout<< "Error: Could not open results.txt for writing!"<< endl;
        return 1;
    }
    resFile<< "Youngest person:"<< youngest.name<< "("<< youngest.age<<")"<< endl;
    resFile<< "Oldest person:" << oldest.name<<"("<< oldest.age<<")"<< endl;
    resFile.close();

    cout<< "Result saved to result.txt ssuccessfully!"<< endl;
    cout<< "Youngest:"<< youngest.name<<"("<< youngest.age<<")"<< endl;
    cout<< "Oldest:" << oldest.name<<"("<< oldest.age<<")"<< endl;

     return 0;
}
