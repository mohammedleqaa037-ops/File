#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
   ofstream outFile("welcome.txt");
    if (!outFile.is_open()) {
        cout << "Error: Could not open welcome.txt for writing!" << endl;
        return 1;
    }
    outFile << "Hello Everybody";
    outFile.close();

    ifstream inFile("welcome.txt");
    if (!inFile.is_open()) {
        cout << "Error: Could not open welcome.txt for reading!" << endl;
        return 1;
    }
    string content;
    getline(inFile, content);
    inFile.close();

    string target = "body";
    string replacement = "one";
    size_t pos = content.find(target);

    if (pos != string::npos) {
        content.replace(pos, target.length(), replacement);
    }
    ofstream finalFile("welcome.txt");
    if (!finalFile.is_open()) {
        cout << "Error: Could not open welcome.txt for updating!" << endl;
        return 1;
    }
    finalFile << content;
    finalFile.close();

    cout << "Updated content in welcome.txt: " << content << endl;

    return 0;
}
