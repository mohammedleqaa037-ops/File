#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
   string FullName, id, grade;

   cout<< "Enter Full Name:";
   getline(cin, FullName);

   cout<< "Enter ID:";
   getline(cin, id);

   cout<< "Enter Grade:";
   getline(cin, grade);

   ofstream myfile("Student.txt");

   if(!myfile.is_open()){
    cout<< "Error, file is not opened"<< endl;
    return 1;
   }

   myfile<< "Full Name:"<< FullName<< endl;
   myfile<< "ID:"<< id<< endl;
   myfile<< "Grade:"<< grade<< endl;

   cout<< "Student data written successfully to Student.txt"<< endl;

   myfile.close();
    return 0;
}
